package com.example.MSA_prac;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsaPracApplicationTests {

	@Test
	void contextLoads() {
	}

}
