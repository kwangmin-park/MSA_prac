package com.example.MSA_prac;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsaPracApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsaPracApplication.class, args);
	}

}
